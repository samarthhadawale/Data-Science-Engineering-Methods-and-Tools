########Importing Libraries###############
library(tibble)
library(dplyr)
library(ggplot2)
library(tm)
library(utf8)
library(udpipe)
library(SnowballC)   
library(stopwords)

####Getting working directory
getwd()
cname <- file.path("C:", "abc")
cname

#####Checking if the file that is to be processed exists in the directory
dir(cname)


##Reading the data with UCS-2LE encoding
hin <- readLines(con <- file("hindi.txt", encoding = "UCS-2LE"))
close(con)
unique(Encoding(hin))


##Udpipe provides language agnostic ???tokenization??? and ???parts of
##speech tagging???, of raw text in many languages, including Chinese
##and Hindi.
model <- udpipe_download_model(language = "hindi")
model <- udpipe_load_model(file = "hindi-hdtb-ud-2.4-190531.udpipe")


##udpipe_annotate() takes the language model and annoates the given text data
x <- udpipe_annotate(model, hin)
x <- data.frame(x) 

##Checking the tokenized results
x$token 
#Checking the Parts of Speech of the tokens
x$upos

################
##  ANALYSIS  ##
################

#Plotting Part-of-speech tags from the given text, use package lattice
library(lattice)
stats <- txt_freq(x$upos)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = stats, col = "yellow", 
         main = "UPOS (Universal Parts of Speech)\n frequency of occurrence", 
         xlab = "Freq")

#Tallying the most common NOUNS from the annotated texts
stats <- subset(x, upos %in% c("NOUN")) 
stats <- txt_freq(stats$token)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = head(stats, 20), col = "cadetblue", 
         main = "Most occurring nouns", xlab = "Freq")

#Tallying the most common ADJECTIVES from the annotated texts
stats <- subset(x, upos %in% c("ADJ")) 
stats <- txt_freq(stats$token)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = head(stats, 20), col = "purple", 
         main = "Most occurring adjectives", xlab = "Freq")

#Tallying the most common VERBS from the annotated texts
stats <- subset(x, upos %in% c("VERB")) 
stats <- txt_freq(stats$token)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = head(stats, 20), col = "gold", 
         main = "Most occurring Verbs", xlab = "Freq")



######WORDCLOUD#######

x$token
x$upos


##Subsetting the Parts-of-Speech which are important for analysis.
##Excluded the Pronouns, Auxilieries,Conjunctions 
stats <- subset(x, upos %in% c("NOUN","VERB","ADJ")) 
stats
stats <- txt_freq(stats$token)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = head(stats, 20), col = "cadetblue", 
         main = "Most occurring tokens", xlab = "Freq")

#####
## WORDCLOUD
#####
## We are considering min freq to be 50 as words below that frequency does not hold 
## high significance and words with maximum frequency above 1000 are common nouns, verbs 
## which are insignificant in the analysis
library(wordcloud)
wordcloud(words = stats$key, freq = stats$freq, min.freq = 50, max.freq = 1000, max.words = 100,
          random.order = FALSE, colors = brewer.pal(6, "Dark2"), scale=c(1,0.5))


