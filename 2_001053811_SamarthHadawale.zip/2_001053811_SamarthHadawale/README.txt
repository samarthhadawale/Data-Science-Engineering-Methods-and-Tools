Amazon
Contains code and dataset for stock prediction of Amazon


Costco
Contains code and dataset for stock prediction of Costco


Time Warner
Contains code and dataset for stock prediction of Time Warner


Stock Analysis.ipynb
Contains code for high-level comparison of stocks of above three companies using matplotlib


Team Information
1. Gayatri Reddiar (001058953)
2. Samarth Hadawale (001053811)